package com.example.exam_oct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamOctApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExamOctApplication.class, args);
    }

}
