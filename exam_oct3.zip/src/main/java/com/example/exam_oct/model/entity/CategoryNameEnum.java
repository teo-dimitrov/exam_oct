package com.example.exam_oct.model.entity;

public enum CategoryNameEnum {
    BATTLE, CARGO, PATROL
}
